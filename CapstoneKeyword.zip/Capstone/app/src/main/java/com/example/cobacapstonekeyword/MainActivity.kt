package com.example.cobacapstonekeyword

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Komponen UI
        val etQuery = findViewById<EditText>(R.id.etQuery)
        val btnSearch = findViewById<Button>(R.id.btnSearch)
        val tvResults = findViewById<TextView>(R.id.tvResults)

        // URL file CSV di Google Cloud Storage
        val csvUrl = "https://storage.googleapis.com/bucketsformodel/keyword_fixed.csv"

        // Event pencarian
        btnSearch.setOnClickListener {
            val query = etQuery.text.toString().trim().lowercase()
            if (query.isEmpty()) {
                tvResults.text = "Masukkan kata kunci terlebih dahulu."
                return@setOnClickListener
            }

            // Proses pencarian dalam coroutine
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val lines = withContext(Dispatchers.IO) { readCsvFromUrl(csvUrl) }

                    // Menyimpan data dari CSV (skip header)
                    val data = mutableListOf<Map<String, String>>()
                    val headers = lines.first().split(",") // Header CSV
                    for (line in lines.drop(1)) { // Mulai dari baris kedua
                        val values = parseCsvLine(line)
                        val row = headers.zip(values).toMap()
                        data.add(row)
                    }

                    // Cari data yang mengandung kata kunci
                    val results = data.filter { row ->
                        val combinedText = row["Keyword"].orEmpty().lowercase()
                        combinedText.contains(query)
                    }

                    // Menampilkan hasil
                    if (results.isEmpty()) {
                        tvResults.text = "Tidak ada hasil yang sesuai untuk kata kunci '$query'."
                    } else {
                        val displayText = results.joinToString("\n") { "- ${it["Nama"]}" }
                        tvResults.text = "Hasil Pencarian:\n$displayText"
                    }
                } catch (e: Exception) {
                    tvResults.text = "Gagal memuat data: ${e.message}"
                }
            }
        }
    }

    // Fungsi untuk membaca CSV langsung dari URL tanpa menyimpan ke lokal
    private fun readCsvFromUrl(urlString: String): List<String> {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        return connection.inputStream.bufferedReader().use(BufferedReader::readLines)
    }

    // Memproses baris CSV yang mengandung koma di dalam kolom
    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        var temp = StringBuilder()
        var inQuotes = false

        for (char in line) {
            when {
                char == ',' && !inQuotes -> {
                    result.add(temp.toString())
                    temp = StringBuilder()
                }
                char == '"' -> {
                    inQuotes = !inQuotes
                }
                else -> {
                    temp.append(char)
                }
            }
        }
        result.add(temp.toString()) // Menambahkan bagian terakhir
        return result
    }
}
